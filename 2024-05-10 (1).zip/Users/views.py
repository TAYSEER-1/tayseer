from datetime import datetime, timedelta

from django.shortcuts import render
from django.utils.crypto import get_random_string
from rest_framework import viewsets, status, mixins
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet
from rest_framework_simplejwt.tokens import RefreshToken

from Products.models import Order
from Products.serializer import OrderSerializer
from Users.models import User, VerificationCode
from Users.permissions import BlockCertainActions
from Users.serializer import *
from utilities import month_diff
from Users.models import User



@api_view(['POST'])
def email_activate(request):
    return Response(status=status.HTTP_200_OK)
    try:

        uuid = request.data['uuid']
        code = request.data['code']
        check_status = VerificationCode.objects.check_verification_code(uuid=uuid, code=code)
        if check_status:

            return Response(status=status.HTTP_200_OK)

        return Response(status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        print("Error: ", e)
        return Response(status=status.HTTP_400_BAD_REQUEST)




@api_view(['GET'])
def commitments_info(request):
    try:
        data = {}
        user=request.user
        # user = User.objects.get()
        student = StudentProfile.objects.get(user=user)
        salary = student.salary
        monthly_installment = float(salary) * 0.4
        loan = student.loan
        if student.loan is None:
            orders = Order.objects.filter(bill__customer=user)
            if orders:
                data['type'] = 'order'
                order = Order.objects.filter(bill__customer=user)[0]
                month = float(order.bill.price) // float(monthly_installment)
                last_month = float(order.bill.price) % float(monthly_installment)
                if last_month > 0:
                    month = month + 1
                today = datetime.date(datetime.now())

                months_paid = month_diff(today, order.order_date)
                month -= months_paid
                data['month'] = month
                data['installment'] = monthly_installment
                data['last_month'] = last_month
                data['amount'] = order.bill.price
                # substract only date and time hours and minutes

                data['start_date'] = order.order_date.__str__()
                data['start_date'] = data['start_date'][0:16]

                data['end_date'] = order.order_date + timedelta(days=30 * month)
                data['end_date'] = data['end_date'].__str__()[0:10]
                image = order.bill.product.image.url.__str__()
                print(image)
                if image.__contains__('https%3A'):
                    image = image.replace('/https%3A/', 'https://')
                print(image)
                data['product_image'] = image
                data['product_name'] = order.bill.product.name
                data['product_price'] = order.bill.price
                if monthly_installment > order.bill.price:
                    data['installment'] = order.bill.price
                    data['last_month'] = 0
                    data['month'] = 0
                    data['paid_amount'] = order.bill.price
                data['remaining_amount'] = float(order.bill.price) - float(months_paid) * float(monthly_installment)
    except Exception as e:
        print("Error: ", e)
        return Response(status=status.HTTP_204_NO_CONTENT)



    else:
        if loan is None:
            return Response(status=status.HTTP_204_NO_CONTENT)
        data['type'] = 'loan'
        month = float(loan.amount) // float(monthly_installment)
        last_month = float(loan.amount) % float(monthly_installment)
        data['installment'] = monthly_installment
        if last_month > 0:
            month = month + 1

        today = datetime.now()
        months_paid = month_diff(today, loan.apply_date)
        month -= months_paid

        data['month'] = month
        data['installment'] = monthly_installment
        data['last_month'] = last_month
        data['amount'] = loan.amount.__str__()
        data['start_date'] = loan.apply_date
        data['end_date'] = loan.apply_date + timedelta(days=30 * month)

        # snapshot.data!['remaining_amount']
        if months_paid == 0:
            data['remaining_amount'] = loan.amount

        elif last_month > 0:
            data['month'] = month - 1
            data['last_month'] = last_month
            data['remaining_amount'] = float(loan.amount) - float(months_paid) * float(monthly_installment)
        else:
            data['remaining_amount'] = float(loan.amount) - float(months_paid) * float(monthly_installment)

        # if
        # data['remaining_amount'] = loan.amount - months_paid * monthly_installment

        data['paid_amount'] = month - 1 * monthly_installment + last_month
    return Response(data)


@api_view(['GET'])
def my_applications(request):
    user = request.user
    if user.is_anonymous:
        return Response(status=status.HTTP_401_UNAUTHORIZED)
    try:
        data = {}
        student = StudentProfile.objects.get(user=user)
        loan = student.loan

        if loan:
            serializer = LoanSerializer(loan, many=False)
            data['loan'] = serializer.data
        orders = Order.objects.filter(bill__customer=user)
        if orders:
            serializer = OrderSerializer(orders.first(), many=False)
            data['order'] = serializer.data
        print(data)
        return Response(data)
    except Exception as e:
        print("Error: ", e)
        return Response(status=status.HTTP_204_NO_CONTENT)


# {"email": "root@root.com", "password": "root"}

@api_view(['POST'])
def auth(request):
    try:
        email = request.data['email']

        password = request.data['password']
        users = User.objects.all()
        user = User.objects.get(email=email.__str__())
        if not user.check_password(password):
            return Response(status=status.HTTP_400_BAD_REQUEST)
        if not user.is_active:
            uuid=VerificationCode.objects.create_verification_code(user)
            return Response({
                'uuid': uuid
            },status=status.HTTP_302_FOUND)

        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'account_type': user.account_type,
        },
            status=status.HTTP_200_OK)
    except Exception as e:
        print("Error: ", e)
        return Response(status=status.HTTP_400_BAD_REQUEST)


class StudentProfileViewSet(
    mixins.RetrieveModelMixin,
    mixins.ListModelMixin,
    GenericViewSet):
    queryset = StudentProfile.objects.all()
    serializer_class = StudentProfileSerializer

    #
    # permission_classes = [BlockCertainActions]

    def list(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous:
            return Response(status=status.HTTP_401_UNAUTHORIZED)
        try:
            profile = StudentProfile.objects.get(user=user)
            serializer = self.get_serializer(profile)
            return Response(serializer.data)
        except Exception as e:
            print(e)
            return Response(status=status.HTTP_204_NO_CONTENT)

    def retrieve(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous:
            return Response(status=status.HTTP_401_UNAUTHORIZED)
        # get pk from request
        pk = kwargs.get('pk')
        if user.id.__str__() == pk or user.account_type == 'admission':
            print("User is the same user or admission")
            return super().retrieve(request, *args, **kwargs)
        return Response(status=status.HTTP_401_UNAUTHORIZED)


class UserAuthViewSet(viewsets.ModelViewSet):
    permission_classes = [BlockCertainActions]
    serializer_class = UserSerializer

    def create(self, request, *args, **kwargs):
        try:
            # username = get_random_string(length=10)
            #
            # الطالب : s442006665@st.uqu.edu.sa
            # الموظف :
            # amgamdi@uqu.edu.sa
            # مكتبة جرير :
            # jarir@jarirbookstore.com
            #              ACCOUNT_TYPE_CHOICES = (
            #         ('admin', 'Admin'),
            #         ('student', 'Student'),
            #         ('admission', 'Admission'),
            #         ('supplier', 'Supplier'),
            #     )

            if request.data['email'].__contains__('@st.uqu.edu.sa'):
                account_type = 'student'
            elif request.data['email'].__contains__('@jarirbookstore.com'):
                account_type = 'supplier'
            elif request.data['email'].__contains__('@uqu.edu.sa'):
                account_type = 'admission'
            else:
                account_type = 'admin'
            user = User.objects.create_user(
                # username=username,
                email=request.data['email'],
                first_name=request.data['first_name'],
                last_name=request.data['last_name'],
                account_type=account_type,
                is_active=False

            )
            VerificationCode.objects.create_verification_code(user)

            user.set_password(request.data['password'])
            user.save()
            return Response(status=status.HTTP_201_CREATED)
        except Exception as e:
            print(e)
            return Response(status=status.HTTP_400_BAD_REQUEST)
