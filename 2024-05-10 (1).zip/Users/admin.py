from django.contrib import admin
from .models import User
from django.contrib.auth.admin import UserAdmin
from Users.models import *
from django.utils.translation import gettext as _

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ['email', 'account_type', 'is_active']
    ordering = ['email']

    fieldsets = (
        (None, {"fields": ("email", "password")}),
        (_("Personal info"), {"fields": ("first_name", "last_name","account_type","address")}),

        (_("Important dates"), {"fields": ("last_login", "date_joined")}),
    )
    radio_fields = {"account_type": admin.HORIZONTAL}
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2"),
            },
        ),
    )
    search_fields = ["email"]



admin.site.register(User, CustomUserAdmin)
admin.site.register(StudentProfile)
admin.site.register(VerificationCode)

