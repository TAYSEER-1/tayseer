EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'tayseer.20240@gmail.com'  # Your Gmail address
# EMAIL_HOST_PASSWORD = 'Aa-123456'  # Your Gmail password or App Password
EMAIL_HOST_PASSWORD = 'fiwd acbd xgum acll'  # Your Gmail password or App Password
