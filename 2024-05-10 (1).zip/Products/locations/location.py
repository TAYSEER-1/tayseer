class Location:
    # name, address, location,distance
    def __init__(self, name, address, location, distance):
        self.name = name
        self.address = address
        self.location = location
        self.distance = distance
#         name, address, location, distance
