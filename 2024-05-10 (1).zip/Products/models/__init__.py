from .product import *
from .bill import *
from .orders import *


faker = Faker()

# for i in range(10):
#     name = faker.name()
#     price = faker.random_int(min=100, max=1000)
#     mark = faker.random_element(elements=('AP', 'HW', 'AD'))
#     category = faker.random_element(elements=('SP', 'TL', 'AC'))
#     image = faker.image_url()
